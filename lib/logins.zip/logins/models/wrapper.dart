class IntWrapper {
  int i = 0;
}

class BoolWrapper {
  bool b = false;
}
