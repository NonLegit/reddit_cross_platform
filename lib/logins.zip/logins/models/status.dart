enum InputStatus { original, taped, sucess, failed }

enum UpperbarStatus { skip, login, signup, none }
